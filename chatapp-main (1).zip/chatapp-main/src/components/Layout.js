import "./Layout.css";

export default function Layout(props) {
  return (
    <div className="Background--styling--registerform">{props.children}</div>
  );
}
